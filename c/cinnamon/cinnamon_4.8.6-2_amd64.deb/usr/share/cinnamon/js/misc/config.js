// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

/* The name of this package (not localized) */
var PACKAGE_NAME = 'cinnamon';
/* The version of this package */
var PACKAGE_VERSION = '4.8.6';
