.. cmake-module:: ../../Modules/FindCUDAToolkit.cmake
