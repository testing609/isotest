.. cmake-module:: ../../Modules/FindSubversion.cmake
