-- this sql should automatically be sourced for upgrades from pre-2.1 versions
update mytable set version='2.1';
